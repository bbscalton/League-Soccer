#!/usr/bin/env python3
"""
League-Soccer Maximum Aggression CPU Team Tactics + Player Tackle Skills

Applies maximum supported pressure/tackle settings to ALL teams and players.
In API mode, both teams are CPU-controlled (no HumanGamers), so all players
receive CPU AI behavior.

TEAM TACTICS changed (all within supported 0.0-1.0 range):
  team_pressure:                          -> 1.0 (maximum zone pressing)
  position_defense_microfocus_strength:   -> 1.0 (tightest ball-carrier marking)
  position_defense_depth_factor:          -> 0.65 (higher defensive line)
  position_defense_width_factor:          -> 0.55 (narrower, more central congestion)

PLAYER SKILLS changed (canonical max is 1.0, clamped in GetStat()):
  technical_standingtackle:               -> 1.0 (maximum standing tackle skill)
  technical_slidingtackle:                -> 1.0 (maximum sliding tackle skill)

NOTE on tackle skills: Higher skill = cleaner tackles = theoretically fewer fouls.
But the user explicitly requested maximum tackle skills alongside maximum pressure.
Combined effect: more tackle attempts (pressure) + better execution (skill).

Usage:
    python apply_max_aggression.py [--db PATH] [--dry-run] [--backup]

Examples:
    python apply_max_aggression.py --backup --db databases/default/default.db
    python apply_max_aggression.py --dry-run  # Preview changes without applying
"""

import argparse
import os
import re
import shutil
import sqlite3
import sys
from datetime import datetime
from typing import Dict, List, Optional, Tuple


# Maximum aggression settings (all within supported 0.0-1.0 range)
MAX_AGGRESSION_TACTICS = {
    "team_pressure": 1.0,                          # Maximum zone pressing
    "position_defense_microfocus_strength": 1.0,   # Tightest marking around ball
    "position_defense_depth_factor": 0.65,         # Higher defensive line
    "position_defense_width_factor": 0.55,         # Narrower shape
}

# Maximum tackle skills for players (canonical max is 1.0)
# Source: src/data/playerdata.cpp:223 - GetStat() clamps to 0.01-1.0
MAX_TACKLE_SKILLS = {
    "technical_standingtackle": 1.0,               # Maximum standing tackle
    "technical_slidingtackle": 1.0,                # Maximum sliding tackle
}


def parse_tactics_xml(xml: str) -> Dict[str, float]:
    """Parse tactics XML into a dict of setting -> value."""
    if not xml:
        return {}
    
    tactics = {}
    # Match <setting_name>value</setting_name> patterns
    pattern = r'<([a-z_]+)>([^<]+)</\1>'
    for match in re.finditer(pattern, xml):
        name, value = match.groups()
        try:
            tactics[name] = float(value)
        except ValueError:
            pass  # Skip non-numeric values
    return tactics


def build_tactics_xml(tactics: Dict[str, float]) -> str:
    """Build tactics XML from a dict."""
    parts = []
    for name, value in sorted(tactics.items()):
        parts.append(f"<{name}>{value:.6f}</{name}>")
    return "".join(parts)


def apply_aggression(current_xml: Optional[str]) -> Tuple[str, Dict[str, Tuple[float, float]]]:
    """
    Apply maximum aggression settings to tactics XML.
    
    Returns:
        (new_xml, changes_dict) where changes_dict maps setting -> (old, new)
    """
    current = parse_tactics_xml(current_xml or "")
    changes = {}
    
    for setting, new_value in MAX_AGGRESSION_TACTICS.items():
        old_value = current.get(setting, 0.5)  # Default is 0.5
        if abs(old_value - new_value) > 0.001:
            changes[setting] = (old_value, new_value)
        current[setting] = new_value
    
    return build_tactics_xml(current), changes


def parse_profile_xml(xml: str) -> Dict[str, float]:
    """Parse player profile XML into a dict of stat -> value."""
    if not xml:
        return {}
    
    profile = {}
    pattern = r'<([a-z_]+)>([^<]+)</\1>'
    for match in re.finditer(pattern, xml):
        name, value = match.groups()
        try:
            profile[name] = float(value)
        except ValueError:
            pass
    return profile


def build_profile_xml(profile: Dict[str, float]) -> str:
    """Build player profile XML from a dict."""
    parts = []
    for name, value in sorted(profile.items()):
        parts.append(f"<{name}>{value:.6f}</{name}>")
    return "".join(parts)


def apply_tackle_skills(current_xml: Optional[str]) -> Tuple[str, Dict[str, Tuple[float, float]]]:
    """
    Apply maximum tackle skills to player profile XML.
    
    Returns:
        (new_xml, changes_dict) where changes_dict maps stat -> (old, new)
    """
    current = parse_profile_xml(current_xml or "")
    changes = {}
    
    for stat, new_value in MAX_TACKLE_SKILLS.items():
        old_value = current.get(stat, 0.5)  # Default profile value is 0.5
        if abs(old_value - new_value) > 0.001:
            changes[stat] = (old_value, new_value)
        current[stat] = new_value
    
    return build_profile_xml(current), changes


def main():
    parser = argparse.ArgumentParser(
        description="Apply maximum aggression CPU team tactics and player tackle skills",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument(
        "--db", 
        default="databases/default/default.db",
        help="Path to the database file (default: databases/default/default.db)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without applying them"
    )
    parser.add_argument(
        "--backup",
        action="store_true", 
        help="Create a backup before modifying (recommended)"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show detailed per-team and per-player changes"
    )
    parser.add_argument(
        "--tactics-only",
        action="store_true",
        help="Only apply team tactics, skip player skill changes"
    )
    parser.add_argument(
        "--skills-only",
        action="store_true",
        help="Only apply player skill changes, skip team tactics"
    )
    args = parser.parse_args()
    
    # Check database exists
    if not os.path.exists(args.db):
        print(f"ERROR: Database not found: {args.db}")
        sys.exit(1)
    
    # Create backup if requested
    if args.backup and not args.dry_run:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = f"{args.db}.backup_{timestamp}"
        shutil.copy2(args.db, backup_path)
        print(f"Created backup: {backup_path}")
    
    # Connect to database
    conn = sqlite3.connect(args.db)
    cursor = conn.cursor()
    
    # =========================================================================
    # PART 1: Team Tactics
    # =========================================================================
    if not args.skills_only:
        cursor.execute("SELECT id, name, tactics_xml FROM teams")
        teams = cursor.fetchall()
        
        print(f"Found {len(teams)} teams in database")
        print(f"\nApplying maximum aggression TEAM TACTICS:")
        for setting, value in MAX_AGGRESSION_TACTICS.items():
            print(f"  {setting}: {value}")
        print()
        
        tactics_changes = 0
        teams_changed = 0
        
        for team_id, team_name, tactics_xml in teams:
            new_xml, changes = apply_aggression(tactics_xml)
            
            if changes:
                teams_changed += 1
                tactics_changes += len(changes)
                
                if args.verbose:
                    print(f"Team {team_id}: {team_name}")
                    for setting, (old, new) in changes.items():
                        print(f"  {setting}: {old:.2f} -> {new:.2f}")
                
                if not args.dry_run:
                    cursor.execute(
                        "UPDATE teams SET tactics_xml = ? WHERE id = ?",
                        (new_xml, team_id)
                    )
        
        if args.dry_run:
            print(f"[DRY RUN] Would change {tactics_changes} tactics across {teams_changed} teams")
        else:
            print(f"Applied {tactics_changes} tactic changes across {teams_changed} teams")
    
    # =========================================================================
    # PART 2: Player Tackle Skills
    # =========================================================================
    if not args.tactics_only:
        cursor.execute("SELECT id, firstname, lastname, profile_xml FROM players")
        players = cursor.fetchall()
        
        print(f"\nFound {len(players)} players in database")
        print(f"\nApplying maximum PLAYER TACKLE SKILLS:")
        for stat, value in MAX_TACKLE_SKILLS.items():
            print(f"  {stat}: {value} (canonical max, clamped 0.01-1.0 in GetStat())")
        print()
        
        skill_changes = 0
        players_changed = 0
        
        for player_id, firstname, lastname, profile_xml in players:
            new_xml, changes = apply_tackle_skills(profile_xml)
            
            if changes:
                players_changed += 1
                skill_changes += len(changes)
                
                if args.verbose:
                    name = f"{firstname} {lastname}".strip() or f"Player {player_id}"
                    print(f"Player {player_id}: {name}")
                    for stat, (old, new) in changes.items():
                        print(f"  {stat}: {old:.2f} -> {new:.2f}")
                
                if not args.dry_run:
                    cursor.execute(
                        "UPDATE players SET profile_xml = ? WHERE id = ?",
                        (new_xml, player_id)
                    )
        
        if args.dry_run:
            print(f"[DRY RUN] Would change {skill_changes} skills across {players_changed} players")
        else:
            print(f"Applied {skill_changes} skill changes across {players_changed} players")
    
    # Commit all changes
    if not args.dry_run:
        conn.commit()
    
    conn.close()
    
    print("\n" + "=" * 70)
    print("SETTINGS EXPLANATION")
    print("=" * 70)
    print("""
TEAM TACTICS (affect AI decision-making):
-----------------------------------------
team_pressure = 1.0 (was typically 0.5)
  - AI starts zone pressing from anywhere on the pitch
  - Zone pressure lasts up to 2300ms (was ~1500ms at 0.5)
  - More closing down = more tackle situations
  - Source: src/onthepitch/teamAIcontroller.cpp:251

position_defense_microfocus_strength = 1.0 (was ~0.5)
  - Defenders cluster tightly around the ball carrier
  - Creates more congestion and physical challenges
  - More 50/50 duels = more potential fouls

position_defense_depth_factor = 0.65 (was ~0.8)
  - Higher defensive line, defenders engage earlier
  - More interceptions and tackle attempts

position_defense_width_factor = 0.55 (was ~0.74)
  - Narrower defensive shape, more central congestion

PLAYER SKILLS (affect tackle execution):
----------------------------------------
technical_standingtackle = 1.0 (canonical max)
  - Used in src/onthepitch/match.cpp:1911
  - Formula: bounceBias += 0.1 + 0.4 * skill
  - At 1.0: bounceBias += 0.5 (maximum tackle success bias)

technical_slidingtackle = 1.0 (canonical max)  
  - Used in src/onthepitch/match.cpp:1913
  - Same formula as standing tackle
  - At 1.0: bounceBias += 0.5 (maximum tackle success bias)

CANONICAL MAX VALUE: 1.0
  - Source: src/data/playerdata.cpp:223
  - GetStat() clamps output to range [0.01, 1.0]
  - Profile values are multiplied by condition modifier before clamping

SCOPE: In API mode (side=0 for both teams), there are no HumanGamers.
All players are CPU-controlled, so these changes affect CPU play only.
""")


if __name__ == "__main__":
    main()
