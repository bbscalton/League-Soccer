-- League-Soccer Maximum Aggression CPU Team Tactics
-- Applies to ALL teams in the database
-- Safe, idempotent - can be run multiple times
-- 
-- BACKUP FIRST: cp databases/default/default.db databases/default/default.db.backup
--
-- Settings changed:
--   team_pressure: 0.5 -> 1.0 (max zone pressing, more tackle situations)
--   position_defense_microfocus_strength: 0.5 -> 1.0 (tightest marking around ball)
--   position_defense_width_factor: 0.5 -> 0.5 (narrow defensive shape, more congestion)
--   position_defense_depth_factor: 0.5 -> 0.6 (slightly higher line, more engagements)
--
-- NOTE: These settings increase TACKLE FREQUENCY, not tackle skill.
-- More tackles = more potential fouls (fouls depend on tackle timing/positioning).
-- Player skill stats (technical_standingtackle, technical_slidingtackle) are unchanged;
-- higher skill = cleaner tackles = fewer fouls per attempt.
--
-- Usage:
--   sqlite3 databases/default/default.db < max_aggression_db.sql

-- Update all teams' tactics_xml to include maximum pressure settings
-- This uses string replacement to inject/update the values

-- First, let's see what we're working with
-- SELECT id, name, tactics_xml FROM teams LIMIT 5;

-- For teams that have tactics_xml set, update the values
-- For teams without tactics_xml, set a complete aggressive configuration

-- Update existing XML entries (replace existing values)
UPDATE teams SET tactics_xml = 
  CASE 
    -- If tactics_xml contains team_pressure, update it
    WHEN tactics_xml LIKE '%<team_pressure>%' THEN
      REPLACE(
        REPLACE(
          REPLACE(
            REPLACE(tactics_xml,
              -- Find and replace team_pressure value
              '<team_pressure>' || SUBSTR(tactics_xml, 
                INSTR(tactics_xml, '<team_pressure>') + 15,
                INSTR(SUBSTR(tactics_xml, INSTR(tactics_xml, '<team_pressure>')), '</team_pressure>') - 16
              ) || '</team_pressure>',
              '<team_pressure>1.000000</team_pressure>'
            ),
            -- This simple approach won't work for nested replacements, so we do multiple passes
            '<position_defense_microfocus_strength>0.5</position_defense_microfocus_strength>',
            '<position_defense_microfocus_strength>1.0</position_defense_microfocus_strength>'
          ),
          '<position_defense_microfocus_strength>0.500000</position_defense_microfocus_strength>',
          '<position_defense_microfocus_strength>1.000000</position_defense_microfocus_strength>'
        ),
        '<team_pressure>0.5</team_pressure>',
        '<team_pressure>1.0</team_pressure>'
      )
    -- If no tactics_xml or empty, create a full aggressive set
    WHEN tactics_xml IS NULL OR tactics_xml = '' THEN
      '<team_pressure>1.000000</team_pressure>' ||
      '<counter_attack>0.500000</counter_attack>' ||
      '<support_distance>0.500000</support_distance>' ||
      '<position_defense_microfocus_strength>1.000000</position_defense_microfocus_strength>' ||
      '<position_defense_depth_factor>0.600000</position_defense_depth_factor>' ||
      '<position_defense_width_factor>0.500000</position_defense_width_factor>'
    -- Otherwise append the new settings
    ELSE
      tactics_xml ||
      '<team_pressure>1.000000</team_pressure>' ||
      '<position_defense_microfocus_strength>1.000000</position_defense_microfocus_strength>'
  END
WHERE 1=1;

-- Verify the changes
-- SELECT id, name, tactics_xml FROM teams LIMIT 5;
