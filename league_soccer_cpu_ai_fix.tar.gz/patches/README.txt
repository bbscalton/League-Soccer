League-Soccer CPU AI Fix Patch
==============================

Date: Nov 6, 2026
Issue: Players stand still after match starts in API mode
Root Cause: menutask.cpp lines ~100-115 assigned both teams to API gamepads
            (side=-1/1) instead of CPU AI (side=0), so the match waited
            for external client input that never came.

Files Modified:
---------------
1. src/menu/menutask.cpp  - Changed API mode to default CPU vs CPU (side=0)
2. src/main.cpp           - Changed reset callback to default CPU vs CPU
3. src/api/match_api.cpp  - Added clarifying comment about done detection

New Files:
----------
4. tools/api_client/seed_automation.py - Automation client for match cycles

How to Apply on Pavilion:
-------------------------
1. Navigate to your League-Soccer checkout:
   cd /path/to/League-Soccer

2. Apply the patch for existing files:
   git apply cpu_ai_fix.patch

3. Copy the new automation script:
   cp seed_automation.py tools/api_client/

4. Rebuild:
   mkdir -p build && cd build
   cmake .. -DCMAKE_BUILD_TYPE=Release
   cmake --build . -j$(nproc)

5. Run the game in API mode:
   ./LeagueSoccer api_mode 1

6. In another terminal, test with automation client:
   cd tools/api_client
   python seed_automation.py --observe
   # Should show match running with in_play=True

What Changed:
-------------
Before: API mode assigned side=-1 (home) and side=1 (away) to API gamepads,
        creating HumanGamer objects that wait for external input.

After:  API mode assigns side=0 (AI) to all controllers, so CPU AI controls
        both teams and the match plays automatically without any connected
        client. The 'action' API command can still inject inputs when needed.

The game now:
- Boots directly into match (no menus/prompts)
- Runs GPU warmup (30 frames) before referee whistle
- Plays CPU vs CPU automatically (no external input needed)
- Skips goal replays
- Auto-continues on game-over (starts new match)
- Listens on TCP port 50051 for observe/reset/step/action commands

Testing the Fix:
----------------
1. Launch game with api_mode 1
2. Run: python seed_automation.py --observe
3. Should see:
   - period > 0 (match active)
   - in_play = True (ball in play)
   - match_time_ms increasing over time
   - Players actually moving and playing

If players still stand still:
- Check console output for "[API] API mode: setting up CPU vs CPU match"
- Verify observe shows period=1 or higher
- Verify no errors in game log


================================================================================
ADDITIONAL: Maximum Aggression CPU Tactics + Player Tackle Skills (Nov 6, 2026)
================================================================================

Purpose: Maximize tackle frequency AND tackle skill for CPU teams

TEAM TACTICS Changed (all within supported 0.0-1.0 range):
----------------------------------------------------------
  team_pressure:                        0.5 -> 1.0  (maximum zone pressing)
  position_defense_microfocus_strength: 0.5 -> 1.0  (tightest marking)
  position_defense_depth_factor:        0.8 -> 0.65 (higher defensive line)
  position_defense_width_factor:        0.74-> 0.55 (narrower, more congestion)

PLAYER SKILLS Changed (canonical max is 1.0):
---------------------------------------------
  technical_standingtackle:             -> 1.0  (maximum standing tackle skill)
  technical_slidingtackle:              -> 1.0  (maximum sliding tackle skill)

Canonical Maximum Value: 1.0
  Source: src/data/playerdata.cpp:223
  GetStat() clamps output to range [0.01, 1.0]
  Formula in match.cpp: bounceBias += 0.1 + 0.4 * skill
  At skill=1.0: bounceBias += 0.5 (maximum tackle success bias)

How It Works:
-------------
- MORE TACKLES: Higher pressure = more closing down = more tackle situations
- MAX SKILL: Both tackle skills set to 1.0 as explicitly requested by user
- SUPPORTED VALUES: All settings within documented ranges, no out-of-range hacks

Files:
------
- apply_max_aggression.py  - Python script to update database (recommended)
- max_aggression_db.sql    - Raw SQL for tactics only (fragile, use Python)

How to Apply (Database Patch):
------------------------------
1. BACKUP your database first:
   cp databases/default/default.db databases/default/default.db.backup

2. Run the Python script (applies BOTH tactics AND skills):
   cd /path/to/League-Soccer
   python patches/apply_max_aggression.py --backup --db databases/default/default.db

3. Preview without applying (optional):
   python patches/apply_max_aggression.py --dry-run --verbose

4. Apply tactics only OR skills only (optional):
   python patches/apply_max_aggression.py --tactics-only --db databases/default/default.db
   python patches/apply_max_aggression.py --skills-only --db databases/default/default.db

Technical Details:
------------------
Team tactics consumed by:
- src/onthepitch/teamAIcontroller.cpp:251 - team_pressure for zone pressing
- src/onthepitch/aitactics.hpp:51-64      - pressure thresholds and duration
- src/onthepitch/AIsupport/AIfunctions.cpp:136 - microfocus positioning

Player tackle skills consumed by:
- src/onthepitch/match.cpp:1911 - technical_standingtackle in bounce bias
- src/onthepitch/match.cpp:1913 - technical_slidingtackle in bounce bias

Foul detection (unchanged, for reference):
- src/onthepitch/referee.cpp:371-450 - TripNotice() determines fouls
- Foul severity based on: timing, ball distance, from-behind angle
- severity > 1.05 = foul, > 1.4 = yellow, > 2.0 = red

SCOPE - CPU-Only in API Mode:
-----------------------------
In API mode with both teams set to side=0 (CPU AI), there are no HumanGamers.
All players receive CPU AI behavior. The database changes affect all players,
but in API mode all players are CPU-controlled, achieving the CPU-only scope.

Configuration Preserved:
------------------------
- match_difficulty = 1.0 (Top Player maximum) - UNCHANGED
- Human/API player controls when side != 0 - UNCHANGED  
- All other player stats - UNCHANGED
- All other game settings - UNCHANGED
